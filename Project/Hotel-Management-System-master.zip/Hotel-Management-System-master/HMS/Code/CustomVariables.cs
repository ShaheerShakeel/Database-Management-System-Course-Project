﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HMS.Code
{
    public class CustomVariables
    {
        public const string HotelFullName = "Hotel Management System";
        public const string HotelShortName = "Hotel Name";
        public const string HotelAbbreviatedName = "HMS";
    }
}